﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;

namespace JeuBalle
{
    public class Balle : Microsoft.Xna.Framework.DrawableGameComponent
    {
        SpriteBatch spriteBatch;
        private int maxX;
        private int maxY;
        private int minX;
        private int minY;


        private Vector2 v_min;
        private Vector2 v_max;
        private Vector2 vitesse_initiale = Vector2.Zero;
        private Vector2 position_initiale;

        private ObjetAnime uneballe;
        private SoundEffect soundRaquette;
        private SoundEffect soundMur;

        private BoundingBox bbox;
        private Raquette raquette1;
        private Raquette raquette2;

        public BoundingBox Bbox
        {
            get
            {
                return bbox;
            }
        }





        public ObjetAnime Uneballe
        {
            get
            {
                return uneballe;
            }
        }

        public Raquette Raquette1
        {
            get
            {
                return raquette1;
            }

            set
            {
                raquette1 = value;
            }
        }

        public Raquette Raquette2
        {
            get
            {
                return raquette2;
            }

            set
            {
                raquette2 = value;
            }
        }

        public Balle(Game game, int x, int y, int z, int w)
            : base(game)
        {
            maxX = x;
            maxY = y;
            minX = z;
            minY = w;


            this.Game.Components.Add(this);

        }

        public override void Initialize()
        {
            // On définit une vitesse initale
            v_min = new Vector2(3, 2);
            v_max = new Vector2(10, 8);
            this.vitesse_initiale = v_min;
            this.position_initiale.X = maxX / 2;
            this.position_initiale.Y = maxY / 2;
            base.Initialize();
        }

        protected override void LoadContent()
        {
            Vector2 taille;
            spriteBatch = new SpriteBatch(GraphicsDevice);
            uneballe = new ObjetAnime(Game.Content.Load<Texture2D>(@"images\balle"),
                this.position_initiale, Vector2.Zero, this.vitesse_initiale);

            soundRaquette = Game.Content.Load<SoundEffect>(@"sons\rebond-raquette");
            soundMur = Game.Content.Load<SoundEffect>(@"sons\rebond-terre_battue");

            taille.X = uneballe.Texture.Width;
            taille.Y = uneballe.Texture.Height;
            uneballe.Size = taille;
            base.LoadContent();
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(uneballe.Texture, uneballe.Position, Color.Azure);
            spriteBatch.End();
            base.Draw(gameTime);
        }

        public override void Update(GameTime gameTime)
        {
            bougeBalle();

            base.Update(gameTime);
        }

        private void balleSortie(int mur)
        {
            Vector2 v;
            Vector2 p;
            ((Jeu)this.Game).but(mur);

            // Le joueur qui vient de marquer relance la balle
            p = uneballe.Position;
            p.X = (maxX / 2) - (uneballe.Size.X / 2);
            p.Y = (maxY / 2) - (uneballe.Size.Y / 2);
            uneballe.Position = p;
            uneballe.Vitesse = this.vitesse_initiale;

            if (((Jeu)this.Game).CeluiQuiAmarque.NoJoueur == 2)
            {
                v = uneballe.Vitesse;
                v.X *= -1;
                uneballe.Vitesse = v;
            }
        }

        // Test la collision et modifie le vecteur vitesse en fonction
        private void gestionCollision()
        {
            Vector2 v;
            // Test de collision
            float[] infosBalle = { uneballe.Position.X, uneballe.Position.Y, uneballe.Size.X, uneballe.Size.Y };
            int[] posRel;
            // avec les raquettes
            if (Moteur2D.testCollision(this, this.raquette1.Bbox))
            {
                // Le prochain mouvement entraîne une collision, on évalue la position relative de la balle
                // par rapport à la raquette pour mettre à jour le vecteur vitesse
                float[] infosRaquette1 = { raquette1.Uneraquette.Position.X, raquette1.Uneraquette.Position.Y, raquette1.Uneraquette.Size.X, raquette1.Uneraquette.Size.Y };
                posRel = Moteur2D.getRelativePosition(infosBalle, infosRaquette1);
                //Console.WriteLine("posRel : x->" + posRel[0] + " - y->" + posRel[1] + "\n\n");

                // Si les 2 objets se croisent sur l'axe des X
                if (posRel[0] == Moteur2D.CROISEMENT)
                {
                    v = uneballe.Vitesse;
                    v.Y *= -1;

                    if (v.Y < v_max.Y)
                        v.Y *= 1.1f;
                    uneballe.Vitesse = v;
                }

                // Si les 2 objets se croisent sur l'axe des Y
                if (posRel[1] == Moteur2D.CROISEMENT)
                {
                    v = uneballe.Vitesse;
                    v.X *= -1;

                    if (v.X < v_max.X)
                        v.X *= 1.1f;
                    uneballe.Vitesse = v;
                }

                SoundEffectInstance soundInstRaquette = soundRaquette.CreateInstance();
                soundInstRaquette.Volume = 0.8f;
                soundInstRaquette.Play();
            }
            else if (Moteur2D.testCollision(this, this.raquette2.Bbox))
            {
                // Le prochain mouvement entraîne une collision, on évalue la position relative de la balle
                // par rapport à la raquette pour mettre à jour le vecteur vitesse
                float[] infosRaquette2 = { raquette2.Uneraquette.Position.X, raquette2.Uneraquette.Position.Y, raquette2.Uneraquette.Size.X, raquette2.Uneraquette.Size.Y };
                posRel = Moteur2D.getRelativePosition(infosBalle, infosRaquette2);
                //Console.WriteLine("posRel : x->" + posRel[0] + " - y->" + posRel[1] + "\n\n");

                // Si les 2 objets se croisent sur l'axe des X
                if (posRel[0] == Moteur2D.CROISEMENT)
                {
                    v = uneballe.Vitesse;
                    v.Y *= -1;

                    if (v.Y < v_max.Y)
                        v.Y *= 1.1f;
                    uneballe.Vitesse = v;
                }

                // Si les 2 objets se croisent sur l'axe des Y
                if (posRel[1] == Moteur2D.CROISEMENT)
                {
                    v = uneballe.Vitesse;
                    v.X *= -1;

                    if (v.X < v_max.X)
                        v.X *= 1.1f;
                    uneballe.Vitesse = v;
                }

                SoundEffectInstance soundInstRaquette = soundRaquette.CreateInstance();
                soundInstRaquette.Volume = 0.8f;
                soundInstRaquette.Play();
            }
            else
            {
                // avec les murs
                bool collision_murs = false;

                if (uneballe.Position.X + uneballe.Size.X <= minX)
                    balleSortie(Moteur2D.MUR_GAUCHE);
                if (uneballe.Position.X >= maxX)
                    balleSortie(Moteur2D.MUR_DROIT);
                if (uneballe.Position.Y + uneballe.Size.Y >= maxY
                    || uneballe.Position.Y <= minY)
                {
                    v = uneballe.Vitesse;
                    v.Y *= -1;

                    if (v.Y < v_max.Y)
                        v.Y *= 1.1f;
                    uneballe.Vitesse = v;
                    collision_murs = true;
                }

                if (collision_murs)
                {
                    SoundEffectInstance soundInstMur = soundMur.CreateInstance();
                    soundInstMur.Volume = 0.6f;
                    soundInstMur.Play();
                }
            }
        }

        private void bougeBalle()
        {
            // on met à jour la Bounding Box
            this.bbox = new BoundingBox(new Vector3(uneballe.Position.X, uneballe.Position.Y, 0),
                                        new Vector3(uneballe.Position.X + uneballe.Texture.Width, uneballe.Position.Y + uneballe.Texture.Height, 0));

            // déplacement de la balle
            uneballe.Position += uneballe.Vitesse;
            // Test la collision et modifie le vecteur vitesse en fonction
            gestionCollision();


        }


    }
}
