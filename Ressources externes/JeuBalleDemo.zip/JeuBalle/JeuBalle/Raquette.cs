﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace JeuBalle
{
    public class Raquette : Microsoft.Xna.Framework.DrawableGameComponent
    {
        SpriteBatch spriteBatch;

        private Joueur joueur;
        private string raquette_filename;
        private ObjetAnime uneraquette;
        private Vector2 position_initiale;

        private int maxY, maxX;
        private int minY;
        private int tailleraquetteX = 50;
        private int tailleraquetteY = 140;

        public const int VITESSE_RAQUETTES = 8;
        private Vector2 vitesse_initiale;

        private BoundingBox bbox;
        private Balle balle;

        public BoundingBox Bbox
        {
            get
            {
                return bbox;
            }
        }

        public ObjetAnime Uneraquette
        {
            get
            {
                return uneraquette;
            }
        }

        public Balle Balle
        {
            get
            {
                return balle;
            }

            set
            {
                balle = value;
            }
        }

        // par le constructeur on initialise les propriétés de la raquette
        public Raquette(Game game, Joueur joueur, string raquette_filename, 
            int vitesse, int tailleho, int tailleverticale)
            : base(game)
        {
            this.joueur = joueur;
            this.raquette_filename = raquette_filename;
            this.vitesse_initiale = new Vector2(0, vitesse);
            this.Game.Components.Add(this);
            maxX = tailleho;
            maxY = tailleverticale - tailleraquetteY / 2;
            minY = 0;
        }

        public override void Initialize()
        {

            base.Initialize();
            



        }

        // On affiche les raquettes
        protected override void LoadContent()
        {
            Vector2 taille;
            spriteBatch = new SpriteBatch(GraphicsDevice);

            if (joueur.NoJoueur == 1)
                this.position_initiale = new Vector2(0, (maxY - tailleraquetteY)/2);
            else if (joueur.NoJoueur == 2)
                this.position_initiale = new Vector2(maxX - tailleraquetteX, (maxY - tailleraquetteY)/2);
            else this.position_initiale = new Vector2(0, 0);
            uneraquette = new ObjetAnime(Game.Content.Load<Texture2D>(@"images\" + raquette_filename), 
                position_initiale, Vector2.Zero, vitesse_initiale);
            taille.X = uneraquette.Texture.Width;
            taille.Y = uneraquette.Texture.Height;
            uneraquette.Size = taille;
            base.LoadContent();
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(uneraquette.Texture, uneraquette.Position, Color.Azure);
            spriteBatch.End();
            base.Draw(gameTime);
        }

        public override void Update(GameTime gameTime)
        {
            Vector2 p;
            // On met à jour la bounding box
            this.bbox = new BoundingBox(new Vector3(uneraquette.Position.X, uneraquette.Position.Y, 0),
                                        new Vector3(uneraquette.Position.X + uneraquette.Size.X, uneraquette.Position.Y + uneraquette.Size.Y, 0));

            // La classe Controls contient les constantes correspondantes aux contrôles définies sur la plate-forme
            // et des méthodes, pour chaque action possible dans le jeu, qui vérifient si les contrôles correspondants
            // ont été "enclenchés"
            if (Controls.CheckActionDown(joueur.NoJoueur))
            {
                if (!Moteur2D.testCollision(this, this.balle.Bbox))
                {
                    // Est-ce qu'on est tout en bas ?
                    if (uneraquette.Position.Y + uneraquette.Size.X < maxY)
                    {
                        p = uneraquette.Position;
                        p.Y += uneraquette.Vitesse.Y;
                        uneraquette.Position = p;
                    }
                }
                else Console.WriteLine("CheckActionDown (joueur" + joueur + ") --> collision ");
            }
            else if (Controls.CheckActionUp(joueur.NoJoueur))
            {
                if (!Moteur2D.testCollision(this, this.balle.Bbox))
                {
                    // Est-ce qu'on est tout en haut ?
                    if (uneraquette.Position.Y > minY)
                    {
                        p = uneraquette.Position;
                        p.Y -= uneraquette.Vitesse.Y;
                        uneraquette.Position = p;
                    }
                }
                else Console.WriteLine("CheckActionUp (joueur" + joueur + ") --> collision ");
            }

            base.Update(gameTime);
        }
    }
}
