using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace JeuBalle
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Jeu : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        private SpriteFont textFont;
        private Texture2D background_motif;
        private Song ambiance;

        private Joueur joueur1;
        private Joueur joueur2;

        private Joueur celuiQuiAmarque;
        internal Joueur CeluiQuiAmarque
        {
            get { return celuiQuiAmarque; }
        }

        public Jeu()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            int maxX, maxY, minX, minY;
            // TODO: Add your initialization logic here

            spriteBatch = new SpriteBatch(GraphicsDevice);
            // on d�finit les coordonn�es de l'�ran de sortie
            maxX = this.GraphicsDevice.Viewport.Width;
            maxY = this.GraphicsDevice.Viewport.Height;
            minX = 0;
            minY = 0;
            joueur1 = new Joueur(this);
            joueur2 = new Joueur(this, 2);
            Balle balle = new Balle(this, maxX, maxY, minX, minY);

            // On r�f�rence la balle dans les raquettes et les raquettes dans la balle pour pouvoir
            // g�rer les collisions
            balle.Raquette1 = joueur1.Raquette;
            balle.Raquette2 = joueur2.Raquette;
            joueur1.Raquette.Balle = balle;
            joueur2.Raquette.Balle = balle;
            // base = classe parent (ici Game)
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            //spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            this.textFont = Content.Load<SpriteFont>("aFont");
            this.background_motif = Content.Load<Texture2D>(@"images\mur");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            drawBgMotif(this.background_motif);

            spriteBatch.Begin();
            spriteBatch.DrawString(this.textFont, "Joueur 1 : " + joueur1.ScoreJoueur, joueur1.PosScoreJoueur, Color.White);
            spriteBatch.DrawString(this.textFont, "Joueur 2 : " + joueur2.ScoreJoueur, joueur2.PosScoreJoueur, Color.White);
            spriteBatch.End();

            // TODO: Add your drawing code here
            base.Draw(gameTime);

        }

        private void drawBgMotif(Texture2D motif)
        {
            int nbMotifsLargeur = this.GraphicsDevice.Viewport.Width / motif.Width + 1;
            Console.WriteLine("nbMotifsLargeur : " + nbMotifsLargeur);
            int nbMotifsHauteur = this.GraphicsDevice.Viewport.Height / motif.Height + 1;
            Console.WriteLine("nbMotifsLargeur : " + nbMotifsLargeur);

            spriteBatch.Begin();
            for (int i = 0; i < nbMotifsLargeur; i++)
            {
                for (int j = 0; j < nbMotifsHauteur; j++)
                    spriteBatch.Draw(this.background_motif,
                                    new Vector2(i * motif.Width, j * motif.Height),
                                    Color.Azure);
            }
            spriteBatch.End();
        }

        public void but(int mur)
        {
            switch (mur)
            {
                case Moteur2D.MUR_GAUCHE:
                    joueur2.updateScore(10);
                    celuiQuiAmarque = joueur2;
                    break;
                case Moteur2D.MUR_DROIT:
                    joueur1.updateScore(10);
                    celuiQuiAmarque = joueur1;
                    break;
            }
        }
    }
}
