﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Input;

namespace JeuBalle
{
    /*
     * Cette classe sert d'abstraction pour les contrôles des joueurs
     * Chaque contrôle (touches clavier, boutons souris, ...) correspond à une action réalisable dans le jeu
     * Le changement d'un contrôle (ex : touche D -> touche E) entraîne la modification d'une seule classe, Controls
     */
    class Controls
    {
        public const Keys JOUEUR1_UP = Keys.E;
        public const Keys JOUEUR1_DOWN = Keys.D;
        public const Keys JOUEUR2_UP = Keys.P;
        public const Keys JOUEUR2_DOWN = Keys.M;

        // Vérifie si le joueur passé en paramètre a effectué l'action "monter la raquette"
        public static Boolean CheckActionUp(int joueur)
        {
            Boolean checkActionUp = false;
            KeyboardState keyboard = Keyboard.GetState();
            switch (joueur)
            {
                case 1:
                    checkActionUp = keyboard.IsKeyDown(JOUEUR1_UP);
                    break;
                case 2:
                    checkActionUp = keyboard.IsKeyDown(JOUEUR2_UP);
                    break;
                default: break;
            }
            return checkActionUp;
        }

        // Vérifie si le joueur passé en paramètre a effectué l'action "descendre la raquette"
        public static Boolean CheckActionDown(int joueur)
        {
            Boolean checkActionDown = false;
            KeyboardState keyboard = Keyboard.GetState();
            switch (joueur)
            {
                case 1:
                    checkActionDown = keyboard.IsKeyDown(JOUEUR1_DOWN);
                    break;
                case 2:
                    checkActionDown = keyboard.IsKeyDown(JOUEUR2_DOWN);
                    break;
                default: break;
            }
            return checkActionDown;
        }
    }
}
